package edu.ggc;

/**
 * Created by tim on 4/12/2017.
 */
public class Person {

    private int phoneNumber;
    private String firstName;
    private String lastName;
    private CacheManager cache;
    private DiskManager disk;

    public Person(CacheManager c, DiskManager d) {
        cache = c;
        disk = d;
    }
    //takes int phoneNumber, String firstName, String lastName as parameters
    public Person(int phoneNumber, String firstName,String lastName) {
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void setPerson(int phoneNumber,String firstName,String lastName) {
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "Person{" +
                "phoneNumber=" + phoneNumber +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }


    public int getPhoneNumber() {
        return phoneNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    // this is the SUT
    public String getFullName(int phoneNumber) {
        Person person = cache.getPerson(phoneNumber);
        if (person == null) {
            person = disk.getPerson(phoneNumber);
        }
        if (person == null) {
            return "";
        }
        return person.firstName + " " + person.lastName;
    }

    @Override
    public boolean equals(Object obj) {
        return  (obj instanceof Person) &&
                ((Person)obj).getFirstName().equals(this.firstName) &&
                ((Person)obj).getLastName().equals(this.lastName) &&
                ((Person)obj).getPhoneNumber() == this.phoneNumber;
    }
}
