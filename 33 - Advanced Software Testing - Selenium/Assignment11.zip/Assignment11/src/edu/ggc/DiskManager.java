package edu.ggc;

/**
 * Created by tim on 4/12/2017.
 */
public interface DiskManager {
    // returns the person identified by the input parameter phone number
    Person getPerson(int phoneNum);
    // returns the phone number of the added person
    int addPerson(Person person);

}
