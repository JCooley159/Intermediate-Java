import edu.ggc.Person;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by tim on 4/12/2017.
 */
public class PersonTest {

    private Person bob;

    @Before
    public void setUp() {
        bob = new Person(123,"Sponge Bob", "Squarepants");
    }

    @Test
    public void test1() {
        //assertEquals("equals method not working!",new Person(),person);
        bob.setPerson(333,"Sponge Robert", "Squarepants");
        assertEquals("name mismatch!","Sponge Robert",bob.getFirstName());
        assertEquals("phone num mismatch!",333,bob.getPhoneNumber());
    }

    @Test
    public void testEqualsMethod() {
        Person bobby = new Person(123,"Sponge Bob", "Squarepants");
        assertEquals("person mismatch",bobby,bob);
        assertTrue("person mismatch",bobby.equals(bob));
    }

    @Test
    public void testGetFullName() {
        Person stewey = new Person(678,"Stewey","Griffin");


    }

}
